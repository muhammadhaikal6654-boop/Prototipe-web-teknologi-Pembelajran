# Paket UI/UX — Misi Perencana Wilayah Boyolali

Paket ini memuat prototipe HTML dan ilustrasi visual yang dipakai pada revisi UI/UX proposal.

## Cara membuka prototipe
1. Ekstrak ZIP ini.
2. Buka `prototype/index.html` dengan Chrome, Edge, Firefox, atau browser modern lain.
3. Prototipe tidak memerlukan instalasi atau server. Koneksi internet hanya diperlukan jika pengguna ingin mengakses sumber daya web eksternal, namun tampilan inti dan interaksi dikemas di dalam HTML.

## Isi paket
- `prototype/index.html`: prototipe interaktif Misi 2 (simulator gravitasi, eksperimen variabel, umpan balik, tantangan, poin, lencana, dan tema gelap).
- `figures/`: aset Gambar 5.1 dan mockup utama untuk proposal serta Lampiran 3.
- `storyboard/`: 16 mockup layar untuk S1.1–S8.1 dan lembar kontak.

## Catatan akademik
Prototipe yang benar-benar dapat dicoba pada file HTML adalah Misi 2. Layar lain di folder storyboard merupakan mockup rancangan untuk tahap produksi, bukan seluruhnya fitur interaktif yang sudah selesai. Angka jarak Boyolali–Surakarta dan Boyolali–Salatiga pada prototipe tetap ditandai sebagai perkiraan dan harus diverifikasi sebelum publikasi final.
